﻿using System.ComponentModel.DataAnnotations;

namespace class_22_JWT_WebApplication1.Models
{
    public class Login
    {
        [Required]
        public string? Email { get; set; }
        [Required]
        [MinLength(8,ErrorMessage ="P bara kar")]
        public string? Password { get; set; }
    }
}
