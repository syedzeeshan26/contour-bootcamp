using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.IdentityModel.Tokens;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters()
        {
            ValidateIssuer = false,
            ValidateAudience = false,
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("MuhammadBilalgdfgdfgfdgfdgfdgdfgfdgdfgfdgfdgdf"))
        };

    });
builder.Services.AddAuthorization(option => {
    option.AddPolicy("IAmAdmin", option2 => {
        option2.RequireClaim("MyRole", "Admin");
    
    });
    option.AddPolicy("IAmUser", option2 => {
        option2.RequireClaim("MyRole", "User");

    });
    //option.AddPolicy("Admin", option => {
    //    option.RequireClaim("MyRole", "Admin");

    //});
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}
app.UseStaticFiles();
app.Use(async (context, next) =>
{
    var token = context.Request.Cookies["Token"];
    context.Request.Headers.Add("Authorization", "Bearer " + token);
    await next();

});

app.UseRouting();
app.UseAuthentication();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
