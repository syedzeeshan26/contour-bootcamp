﻿using class_22_JWT_WebApplication1.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.Diagnostics;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace class_22_JWT_WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Login()
        {
            return View();
        }
        [Authorize(Policy = "IAmAdmin")]
        public IActionResult Admin()
        {
            return View();
        }
        [Authorize(Policy = "IAmUser")]
        public IActionResult User()
        {
            return View();
        }
        public IActionResult Submit(Login login)
            
        {
            
            ViewData["Email"] = login.Email;
            ViewData["Password"] = login.Password;
            var SecurityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("MuhammadBilalgdfgdfgfdgfdgfdgdfgfdgdfgfdgfdgdf"));
 
                //Algorithm With Key
                var Cridantial = new SigningCredentials(SecurityKey, SecurityAlgorithms.HmacSha256);
 
 
                
 
                var claimes = new List<Claim>() { 
                    new Claim("Name", login.Email!),
                    new Claim("DOB","sdsfds"),
                    new Claim("MyRole","Admin")
                };
 
 
 
                var token = new JwtSecurityToken(
                    signingCredentials: Cridantial,
                    claims: claimes,
                    expires: DateTime.Now.AddHours(1)
                );



            var JWTToken = new JwtSecurityTokenHandler().WriteToken(token);

            ViewData["Token"] = JWTToken;

            var option = new CookieOptions()
            {
                Expires = DateTime.Now.AddHours(1),
                Secure = true,
                HttpOnly = true

            };
            HttpContext.Response.Cookies.Append("Token",JWTToken,option);
            //HttpContext.Response.Headers.Add("Set-Cookies",option");

            return View();
        }
        [Authorize]
        public IActionResult Privacy()
        {
            
                return View();
            
            
        }
        public IActionResult Logout()
        {
            HttpContext.Response.Cookies.Append("Token", "");
            return RedirectToAction("Login");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
