﻿using System.ComponentModel.DataAnnotations;

namespace EntityFramWorkTest.Models
{
    public class Address
    {
        [Key]
        public  int Id { get; set; }

        [Required]
        public string city { get; set; }

        [Required]
        public string State { get; set; }

        [Required]
        public string Contry { get; set; }
    }
}
