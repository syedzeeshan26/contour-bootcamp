﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EntityFramWorkTest.Migrations
{
    /// <inheritdoc />
    public partial class second : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "emaPhoneil",
                table: "students",
                newName: "Phone");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Phone",
                table: "students",
                newName: "emaPhoneil");
        }
    }
}
