﻿using EntityFramWorkTest.Models;
using Microsoft.EntityFrameworkCore;

namespace EntityFramWorkTest.MyDbContext
{
    public class SchoolMS : DbContext
    {
        public SchoolMS(DbContextOptions<SchoolMS> contextOptions) : base(contextOptions) { }
        public DbSet<Student> students { get; set; }
        public DbSet<Address> addresses { get; set; }


    }
}
