﻿using EntityFramWorkTest.Models;
using EntityFramWorkTest.MyDbContext;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace EntityFramWorkTest.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private SchoolMS _shoolMS;
        private int myid;

        public HomeController(ILogger<HomeController> logger, SchoolMS school)
        {



            _logger = logger;
            _shoolMS = school;
        }
        
        public IActionResult Index(int id)
        {
            myid = id;
            Address address = new Address() { city = "multan", State = "Punjab", Contry = "Pakistan" };
            _shoolMS.addresses.Add(address);
            _shoolMS.SaveChanges();


            _shoolMS.addresses.Add(address);

            return View();
        }

        public IActionResult Privacy()
        {
            Console.WriteLine(myid);

            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}