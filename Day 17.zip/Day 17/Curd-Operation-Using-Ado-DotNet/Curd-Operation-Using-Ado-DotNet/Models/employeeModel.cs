﻿namespace Curd_Operation_Using_Ado_DotNet.Models
{
    public class employeeModel
    {
        public int EmpId { get; set; }
        public string EmpName { get; set; }
        public int EmpSalary { get; set; }

    }
}
