﻿using System.Data;
using System.Data.SqlClient;

namespace Curd_Operation_Using_Ado_DotNet.Models
{
    public class EmployeeContext
    {
        SqlConnection con = new SqlConnection("Data Source=CRKRW-MVC5;Initial Catalog=Employee;Integrated Security=true");
        
    }
}
